package com.medstore.tests;


import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.lang.reflect.Field;
import java.sql.*;
import java.util.List;
import Backend.Medicine;
import Backend.Supplier;
import Database.DBhandler;

public class DBhandlerTest {
    private DBhandler dbHandler;
    private Connection connection;

    @Before
    public void setUp() throws Exception {
        dbHandler = DBhandler.getInstance();
        // Access private connection using reflection
        Field connectionField = DBhandler.class.getDeclaredField("connection");
        connectionField.setAccessible(true);
        connection = (Connection) connectionField.get(dbHandler);
        connection.setAutoCommit(false); // Start transaction
    }

    @After
    public void tearDown() throws Exception {
        connection.rollback(); // Rollback after each test
        connection.setAutoCommit(true);
    }

    // Helper methods
    private void insertTestUser() throws SQLException {
        try (PreparedStatement stmt = connection.prepareStatement(
            "INSERT INTO User1 (username1, password1) VALUES (?, ?)")) {
            stmt.setString(1, "testUser");
            stmt.setString(2, "testPass");
            stmt.executeUpdate();
        }
    }

    private int insertTestMedicine() throws SQLException {
        Medicine med = new Medicine("TestMed", "TestDesc", 100, 50, "2023-01-01", "2024-01-01");
        dbHandler.addMedicine(med);
        
        try (PreparedStatement stmt = connection.prepareStatement(
            "SELECT MID FROM Meds WHERE name1 = 'TestMed'")) {
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? rs.getInt("MID") : -1;
        }
    }

    private void insertTestSale(int mid) throws SQLException {
        try (PreparedStatement stmt = connection.prepareStatement(
            "INSERT INTO Sales (MID, bought) VALUES (?, ?)")) {
            stmt.setInt(1, mid);
            stmt.setInt(2, 10);
            stmt.executeUpdate();
        }
    }

    // Test cases
    @Test
    public void testValidateUser() throws SQLException {
        insertTestUser();
        assertTrue(dbHandler.validateUser("testUser", "testPass"));
        assertFalse(dbHandler.validateUser("wrong", "credentials"));
    }

    @Test
    public void testMedicineCRUD() throws SQLException {
        // Test addMedicine
        Medicine testMed = new Medicine("CRUDTest", "Test", 100, 50, "2023-01-01", "2024-01-01");
        assertTrue(dbHandler.addMedicine(testMed));
        
        // Test getAllMedicines
        List<String> medicines = dbHandler.getAllMedicines();
        assertTrue(medicines.contains("CRUDTest"));
        
        // Test getMedicineDetails
        Medicine retrieved = dbHandler.getMedicineDetails("CRUDTest");
        assertEquals(100, retrieved.getPrice());
        
        // Test updateMedicinePrice
        assertTrue(dbHandler.updateMedicinePrice("CRUDTest", 150));
        retrieved = dbHandler.getMedicineDetails("CRUDTest");
        assertEquals(150, retrieved.getPrice());
        
        // Test removeMedicine
        dbHandler.removeMedicine("CRUDTest");
        assertNull(dbHandler.getMedicineDetails("CRUDTest"));
    }

    @Test
    public void testStockOperations() throws SQLException {
        insertTestMedicine();
        
        // Test updateMedicineStock
        assertTrue(dbHandler.updateMedicineStock("TestMed", 75));
        Medicine med = dbHandler.getMedicineDetails("TestMed");
        assertEquals(75, med.getStock());
        
        // Test getLowStockMeds
        dbHandler.updateMedicineStock("TestMed", 5);
        List<String> lowStock = dbHandler.getLowStockMeds();
        assertTrue(lowStock.get(0).contains("TestMed"));
    }

    @Test
    public void testExpiryHandling() throws SQLException {
        // Insert expired medicine
        Medicine expired = new Medicine("ExpiredMed", "Test", 100, 10, "2020-01-01", "2021-01-01");
        dbHandler.addMedicine(expired);
        
        List<String> expiredMeds = dbHandler.getExpiredMedicines();
        assertTrue(expiredMeds.contains("ExpiredMed"));
    }

    @Test
    public void testSalesReporting() throws SQLException {
        int mid = insertTestMedicine();
        insertTestSale(mid);
        
        // Test getTotalSales
        assertEquals(10, dbHandler.getTotalSales("TestMed"));
        
        // Test getTopMedicinesBySales
        List<String> topMeds = dbHandler.getTopMedicinesBySales();
        assertTrue(topMeds.contains("TestMed"));
    }

    @Test
    public void testLoggingSystem() {
        // Test addLog
        assertTrue(dbHandler.addLog("Test log entry"));
        
        // Test getLogsDescending
        List<String> logs = dbHandler.getLogsDescending();
        assertTrue(logs.get(0).contains("Test log entry"));
    }

    @Test
    public void testSupplierCRUD() {
        // Test addSupplier
        Supplier supplier = new Supplier("TestSupplier", "555-1234", "test@test.com", "Test Address", "LIC123");
        assertTrue(dbHandler.addSupplier(supplier));
        
        // Test getAllSupplierNames
        List<String> suppliers = dbHandler.getAllSupplierNames();
        assertTrue(suppliers.contains("TestSupplier"));
        
        // Test getSupplierDetails
        Supplier retrieved = dbHandler.getSupplierDetails("TestSupplier");
        assertEquals("test@test.com", retrieved.getEmail());
        
        // Test deleteSupplier
        assertTrue(dbHandler.deleteSupplier("TestSupplier"));
        suppliers = dbHandler.getAllSupplierNames();
        assertFalse(suppliers.contains("TestSupplier"));
    }

    @Test
    public void testEdgeCases() {
        // Test non-existent medicine
        assertFalse(dbHandler.updateMedicineStock("NonExistent", 10));
        assertFalse(dbHandler.updateMedicinePrice("NonExistent", 100));
        
        // Test empty results
        List<String> expired = dbHandler.getExpiredMedicines();
        assertTrue(expired.isEmpty());
        
        // Test invalid delete
        assertFalse(dbHandler.deleteSupplier("NonExistentSupplier"));
    }
}