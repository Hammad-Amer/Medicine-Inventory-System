package com.medstore.tests;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({
	SupplierTest.class,
    ControllerTest.class,
    DBhandlerTest.class,
    ControllerTest2.class,
    FX1.class,
    FX2.class,
    FX3.class
})
public class AllTests {
}
