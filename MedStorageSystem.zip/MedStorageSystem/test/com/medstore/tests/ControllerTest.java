package com.medstore.tests;

import static org.junit.Assert.*;
import org.junit.Test;

import Backend.Medicine;
import Backend.Supplier;
import Backend.User;
import Backend.Sales;

import ui.Controller;
import javafx.scene.control.TextField;

public class ControllerTest {

    // Controller tests
    @Test
    public void testSetAndGetUser() {
        Controller.setUser("admin");
        assertEquals("admin", Controller.getUser());
    }

    @Test
    public void testSetAndGetUserEmpty() {
        Controller.setUser("");
        assertEquals("", Controller.getUser());
    }

    @Test
    public void testSetAndGetUserNull() {
        Controller.setUser(null);
        assertNull(Controller.getUser());
    }

    

    @Test
    public void testMedicineConstructor() {
        Medicine med = new Medicine("Paracetamol", "Pain killer", 50, 100, "2023-01-01", "2025-01-01");
        assertEquals("Paracetamol", med.getName());
    }

    @Test
    public void testMedicineGetPrice() {
        Medicine med = new Medicine("Paracetamol", "Pain killer", 50, 100, "2023-01-01", "2025-01-01");
        assertEquals(50, med.getPrice());
    }

    @Test
    public void testMedicineGetStock() {
        Medicine med = new Medicine("Paracetamol", "Pain killer", 50, 100, "2023-01-01", "2025-01-01");
        assertEquals(100, med.getStock());
    }

    // --- Supplier simple tests ---

    @Test
    public void testSupplierGetPhone() {
        Supplier supplier = new Supplier("XYZ Pharma", "03001234567", "xyz@pharma.com", "Lahore", "LIC123");
        assertEquals("03001234567", supplier.getPhone());
    }

    @Test
    public void testSupplierGetAddress() {
        Supplier supplier = new Supplier("XYZ Pharma", "03001234567", "xyz@pharma.com", "Lahore", "LIC123");
        assertEquals("Lahore", supplier.getAddress());
    }

    // --- User simple tests ---

    @Test
    public void testUserGetEmail() {
        User user = new User(1, "user@example.com", "pass123");
        assertEquals("user@example.com", user.getEmail());
    }

    @Test
    public void testUserGetPassword() {
        User user = new User(1, "user@example.com", "pass123");
        assertEquals("pass123", user.getPassword());
    }

    // --- Sales simple tests ---

    @Test
    public void testSalesGetQuantityBought() {
        Sales sale = new Sales(1, 101, 3);
        assertEquals(3, sale.getQuantityBought());
    }

    @Test
    public void testSalesGetMedicineID() {
        Sales sale = new Sales(1, 101, 3);
        assertEquals(101, sale.getMedicineID());
    }
}

class FakeTextField {
    private String text;

    public FakeTextField(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }
}
