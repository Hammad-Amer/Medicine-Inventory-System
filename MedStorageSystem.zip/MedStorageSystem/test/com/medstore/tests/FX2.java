package com.medstore.tests;

import static org.junit.Assert.*;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import org.junit.BeforeClass;
import org.junit.Test;
import java.util.concurrent.CountDownLatch;

public class FX2 {
    private static Parent root;
    private static final CountDownLatch latch = new CountDownLatch(1);

    @BeforeClass
    public static void setUpClass() throws Exception {
        // Initialize JavaFX toolkit
        new JFXPanel();
        
        Platform.runLater(() -> {
            try {
                root = FXMLLoader.load(FX2.class.getResource("/ui/AddSupp.fxml"));
                latch.countDown();
            } catch (Exception e) {
                fail("FXML loading failed: " + e.getMessage());
            }
        });
        latch.await();
    }

    @Test
    public void testMainComponentsExist() {
        assertNotNull("Root node not loaded", root);
        
        // Verify input fields
        assertNotNull("Name field missing", root.lookup("#AddSupp_name"));
        assertNotNull("Phone field missing", root.lookup("#AddSupp_phone"));
        assertNotNull("Email field missing", root.lookup("#AddSupp_email"));
        assertNotNull("Address field missing", root.lookup("#AddSupp_address"));
        assertNotNull("License field missing", root.lookup("#AddSupp_Lnum"));
        
        // Verify buttons
        assertNotNull("Add button missing", root.lookup("#AddSupp_addbutton"));
        assertNotNull("Back button missing", root.lookup("#AddMeds_back"));
    }

    @Test
    public void testButtonConfiguration() {
        Button addButton = (Button) root.lookup("#AddSupp_addbutton");
        Button backButton = (Button) root.lookup("#AddMeds_back");
        
        assertEquals("ADD", addButton.getText());
        assertEquals("BACK", backButton.getText());
        assertTrue("Add button missing style class", 
                  addButton.getStyleClass().contains("create-btn"));
    }

    @Test
    public void testLabelsContent() {
        // Verify main title
        Text title = (Text) root.lookup(".text.head-label");
        assertEquals("Medical Store Inventory", title.getText());
        
        // Verify form labels
        assertNotNull(root.lookup("Text[text='Supplier Name:']"));
        assertNotNull(root.lookup("Text[text='Phone:']"));
        assertNotNull(root.lookup("Text[text='Email:']"));
        assertNotNull(root.lookup("Text[text='Address:']"));
        assertNotNull(root.lookup("Text[text='License Number:']"));
    }

    @Test
    public void testInputFieldProperties() {
        TextField nameField = (TextField) root.lookup("#AddSupp_name");
        TextField licenseField = (TextField) root.lookup("#AddSupp_Lnum");
        
        assertEquals("Name field width incorrect", 288, (int) nameField.getPrefWidth());
        assertEquals("License field width incorrect", 288, (int) licenseField.getPrefWidth());
    }

    @Test
    public void testControllerAssociation() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.load(getClass().getResource("/ui/AddSupp.fxml").openStream());
            assertNotNull("Controller not associated", loader.getController());
        } catch (Exception e) {
            fail("Controller test failed: " + e.getMessage());
        }
    }
}