package com.medstore.tests;

import static org.junit.Assert.*;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.text.Text;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.concurrent.CountDownLatch;

public class FX5_RemoveSupplier {
    private static Parent root;
    private static final CountDownLatch latch = new CountDownLatch(1);

    @BeforeClass
    public static void init() throws Exception {
        new JFXPanel();
        Platform.runLater(() -> {
            try {
                root = FXMLLoader.load(FX5_RemoveSupplier.class.getResource("/ui/RemSupp.fxml"));
                latch.countDown();
            } catch (Exception e) {
                fail("Failed to load DelSupp.fxml: " + e.getMessage());
            }
        });
        latch.await();
    }

    @Test
    public void testComponentsExist() {
        assertNotNull("Root not loaded", root);
        assertNotNull("Back button missing", root.lookup("#DelMeds_BackButton"));
        assertNotNull("ComboBox missing", root.lookup("#DelSupp_Combobox"));
        assertNotNull("Remove Supplier button missing", root.lookup("#DelSupp_removebut"));
        // detail Text nodes
        assertNotNull("Name text missing", root.lookup("#DelSupp_name"));
        assertNotNull("Phone text missing", root.lookup("#DelSupp_phone"));
        assertNotNull("Email text missing", root.lookup("#DelSupp_email"));
        assertNotNull("Address text missing", root.lookup("#DelSupp_adress"));
        assertNotNull("License# text missing", root.lookup("#DelSupp_LCnum"));
    }

    @Test
    public void testButtonTexts() {
        assertEquals("BACK", ((Button)root.lookup("#DelMeds_BackButton")).getText());
        assertEquals("REMOVE SUPPLIER", ((Button)root.lookup("#DelSupp_removebut")).getText());
    }

    @Test
    public void testTitleText() {
        Text title = (Text) root.lookup(".head-label2");
        assertEquals("Remove Supplier", title.getText());
    }
}
