package com.medstore.tests;

import static org.junit.Assert.*;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.text.Text;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.concurrent.CountDownLatch;

public class FX4_SearchMeds {
    private static Parent root;
    private static final CountDownLatch latch = new CountDownLatch(1);

    @BeforeClass
    public static void init() throws Exception {
        new JFXPanel();
        Platform.runLater(() -> {
            try {
                root = FXMLLoader.load(FX4_SearchMeds.class.getResource("/ui/SearchMeds.fxml"));
                latch.countDown();
            } catch (Exception e) {
                fail("Failed to load SearchMeds.fxml: " + e.getMessage());
            }
        });
        latch.await();
    }

    @Test
    public void testComponentsExist() {
        assertNotNull("Root not loaded", root);
        assertNotNull("Back button missing", root.lookup("#SearchMeds_BackButton"));
        assertNotNull("ComboBox missing", root.lookup("#SearchMeds_Combobox"));
        // result Text nodes
        assertNotNull("Name text missing", root.lookup("#SearchMeds_Name"));
        assertNotNull("Desc text missing", root.lookup("#SearchMeds_Desc"));
        assertNotNull("Price text missing", root.lookup("#SearchMeds_Price"));
        assertNotNull("Stock text missing", root.lookup("#SearchMeds_Stock"));
        assertNotNull("ManDate text missing", root.lookup("#SearchMeds_ManDate"));
        assertNotNull("ExpDate text missing", root.lookup("#SearchMeds_ExpDate"));
    }

    @Test
    public void testButtonAndPromptText() {
        Button back = (Button) root.lookup("#SearchMeds_BackButton");
        ComboBox<?> combo = (ComboBox<?>) root.lookup("#SearchMeds_Combobox");
        assertEquals("BACK", back.getText());
        assertEquals("Search", combo.getPromptText());
    }

    @Test
    public void testTitleText() {
        Text title = (Text) root.lookup(".head-label");
        assertEquals("Medical Store Inventory", title.getText());
    }
}
