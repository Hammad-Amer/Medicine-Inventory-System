package com.medstore.tests;
import static org.junit.Assert.*;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import org.junit.BeforeClass;
import org.junit.Test;
import java.util.concurrent.CountDownLatch;

public class FX1 {
    private static Parent root;
    private static final CountDownLatch latch = new CountDownLatch(1);

    @BeforeClass
    public static void setUpClass() throws Exception {
        // Initialize JavaFX toolkit
        new JFXPanel();
        
        // Load FXML on FX application thread
        Platform.runLater(() -> {
            try {
                root = FXMLLoader.load(FX1.class.getResource("/ui/AddMeds.fxml"));
                latch.countDown();
            } catch (Exception e) {
                fail("FXML loading failed: " + e.getMessage());
            }
        });
        
        // Wait for loading to complete
        latch.await();
    }

    @Test
    public void testMainComponentsExist() {
        assertNotNull("Root node not loaded", root);
        assertNotNull("Name field missing", root.lookup("#AddMeds_name"));
        assertNotNull("Price field missing", root.lookup("#AddMeds_price"));
    }

    @Test
    public void testButtonTexts() {
        Button addButton = (Button) root.lookup("#AddMeds_AddButton");
        Button backButton = (Button) root.lookup("#AddMeds_back");
        
        assertEquals("ADD", addButton.getText());
        assertEquals("BACK", backButton.getText());
    }

    @Test
    public void testTitleText() {
        Text title = (Text) root.lookup(".text.head-label");
        assertEquals("Medical Store Inventory", title.getText());
    }
}