package com.medstore.tests;

import org.junit.Test;
import static org.junit.Assert.*;

import Backend.Medicine;
import Backend.Supplier;
import Backend.Sales;
import Backend.User;

public class SupplierTest {
  
    @Test
    public void testSupplierConstructorAndGetters() {
        String name    = "ABC Pharma";
        String phone   = "03001234567";
        String email   = "abc@xyz.com";
        String address = "123 Main St, Lahore";
        String license = "LIC12345";

        Supplier s = new Supplier(name, phone, email, address, license);

        assertEquals(name,    s.getSupplierName());
        assertEquals(phone,   s.getPhone());
        assertEquals(email,   s.getEmail());
        assertEquals(address, s.getAddress());
        assertEquals(license, s.getLicenseNumber());
    }

    @Test
    public void testMedicineConstructorAndGetters() {
        String name = "Panadol";
        String description = "Pain relief";
        int price = 50;
        int stock = 100;
        String manDate = "2023-01-01";
        String expDate = "2025-01-01";

        Medicine med = new Medicine(name, description, price, stock, manDate, expDate);

        assertEquals(name,        med.getName());
        assertEquals(description, med.getDescription());
        assertEquals(price,       med.getPrice());
        assertEquals(stock,       med.getStock());
        assertEquals(manDate,     med.getManDate());
        assertEquals(expDate,     med.getExpDate());
    }

    @Test
    public void testSalesConstructorAndGetters() {
        int saleID = 1;
        int medicineID = 101;
        int quantityBought = 5;

        Sales sale = new Sales(saleID, medicineID, quantityBought);

        assertEquals(saleID,         sale.getSaleID());
        assertEquals(medicineID,     sale.getMedicineID());
        assertEquals(quantityBought, sale.getQuantityBought());
    }

    @Test
    public void testUserConstructorAndGetters() {
        int userID = 1;
        String email = "user@example.com";
        String password = "password123";

        User user = new User(userID, email, password);

        assertEquals(userID,    user.getUserID());
        assertEquals(email,     user.getEmail());
        assertEquals(password,  user.getPassword());
    }
}
