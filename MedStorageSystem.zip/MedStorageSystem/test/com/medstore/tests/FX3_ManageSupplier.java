package com.medstore.tests;

import static org.junit.Assert.*;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.concurrent.CountDownLatch;

public class FX3_ManageSupplier {
    private static Parent root;
    private static final CountDownLatch latch = new CountDownLatch(1);

    @BeforeClass
    public static void init() throws Exception {
        new JFXPanel();
        Platform.runLater(() -> {
            try {
                root = FXMLLoader.load(FX3_ManageSupplier.class.getResource("/ui/Supplier.fxml"));
                latch.countDown();
            } catch (Exception e) {
                fail("Failed to load ManageSupplier.fxml: " + e.getMessage());
            }
        });
        latch.await();
    }

    @Test
    public void testComponentsExist() {
        assertNotNull("Root not loaded", root);
        assertNotNull("Add Supplier button missing", root.lookup("#Supp_addsupp"));
        assertNotNull("Get Supplier button missing", root.lookup("#Supp_getsupp"));
        assertNotNull("Remove Supplier button missing", root.lookup("#Supp_remsupp"));
        assertNotNull("Medicines nav button missing", root.lookup("#Supp_gotomedsscreen"));
    }

    @Test
    public void testButtonTexts() {
        assertEquals("Add New Supplier", ((Button)root.lookup("#Supp_addsupp")).getText());
        assertEquals("Get Supplier Details", ((Button)root.lookup("#Supp_getsupp")).getText());
        assertEquals("Remove a Supplier", ((Button)root.lookup("#Supp_remsupp")).getText());
        assertEquals("Medicines", ((Button)root.lookup("#Supp_gotomedsscreen")).getText());
    }

    @Test
    public void testTitleText() {
        Text title = (Text) root.lookup(".head-label");
        assertEquals("Manage Supplier", title.getText());
    }
}
