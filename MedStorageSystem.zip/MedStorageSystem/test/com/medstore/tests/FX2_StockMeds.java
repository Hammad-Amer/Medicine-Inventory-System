package com.medstore.tests;

import static org.junit.Assert.*;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.concurrent.CountDownLatch;

public class FX2_StockMeds {
    private static Parent root;
    private static final CountDownLatch latch = new CountDownLatch(1);

    @BeforeClass
    public static void init() throws Exception {
        new JFXPanel();  // initialize JavaFX
        Platform.runLater(() -> {
            try {
                root = FXMLLoader.load(FX2_StockMeds.class.getResource("/ui/UpdateMedStock.fxml"));
                latch.countDown();
            } catch (Exception e) {
                fail("Failed to load StockMeds.fxml: " + e.getMessage());
            }
        });
        latch.await();
    }

    @Test
    public void testComponentsExist() {
        assertNotNull("Root not loaded", root);
        assertNotNull("Back button missing", root.lookup("#StockMeds_BackButton"));
        assertNotNull("ComboBox missing", root.lookup("#StcokMeds_Combobox"));
        assertNotNull("Add-to-stock Button missing", root.lookup("#SearchMeds_Addbutton"));
        assertNotNull("Stock input field missing", root.lookup("#StcokMeds_addstock"));
        assertNotNull("Name text node missing", root.lookup("#StcokMeds_name"));
        assertNotNull("Description text node missing", root.lookup("#StcokMeds_desciption"));
        assertNotNull("Price text node missing", root.lookup("#StcokMeds_price"));
        assertNotNull("CurrentStock text node missing", root.lookup("#StcokMeds_currentstock"));
    }

    @Test
    public void testButtonTexts() {
        Button back = (Button) root.lookup("#StockMeds_BackButton");
        Button add  = (Button) root.lookup("#SearchMeds_Addbutton");
        assertEquals("BACK", back.getText());
        assertEquals("ADD", add.getText());
    }

    @Test
    public void testTitleText() {
        Text title = (Text) root.lookup(".head-label");
        assertEquals("Medical Store Inventory", title.getText());
    }
}
