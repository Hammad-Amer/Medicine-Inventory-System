package com.medstore.tests;

import static org.junit.Assert.*;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import org.junit.BeforeClass;
import org.junit.Test;
import java.util.concurrent.CountDownLatch;

public class FX3 {
	  private static Parent root;
	    private static final CountDownLatch latch = new CountDownLatch(1);

	    @BeforeClass
	    public static void setUpClass() throws Exception {
	        // Initialize JavaFX toolkit
	        new JFXPanel();
	        
	        Platform.runLater(() -> {
	            try {
	                // Verify correct resource path
	                String fxmlPath = "/ui/UpdateMedStock.fxml"; // Match actual filename
	                root = FXMLLoader.load(FX3.class.getResource(fxmlPath));
	                latch.countDown();
	            } catch (Exception e) {
	                fail("FXML loading failed. Verify: "
	                     + "\n1. File exists in src/main/resources/ui/"
	                     + "\n2. Filename matches exactly (case-sensitive)"
	                     + "\n3. File is included in build path\n"
	                     + "Error: " + e.getMessage());
	            }
	        });
	        latch.await();
	    }

	    @Test
	    public void testFXMLStructure() {
	        assertNotNull("FXML root node not loaded", root);
	        assertNotNull("ComboBox missing", root.lookup("#StcokMeds_Combobox"));
	        assertNotNull("Add button missing", root.lookup("#SearchMeds_Addbutton"));
	    }
    @Test
    public void testCoreComponentsExist() {
        assertNotNull("Root node not loaded", root);
        
        // Verify main components
        assertNotNull("Medicine combo box missing", root.lookup("#StcokMeds_Combobox"));
        assertNotNull("Add stock field missing", root.lookup("#StcokMeds_addstock"));
        assertNotNull("Add button missing", root.lookup("#SearchMeds_Addbutton"));
        assertNotNull("Back button missing", root.lookup("#StockMeds_BackButton"));
    }

    @Test
    public void testTextComponents() {
        // Verify main title
        Text title = (Text) root.lookup(".text.head-label");
        assertEquals("Medical Store Inventory", title.getText());
        
        // Verify section title
        Text sectionTitle = (Text) root.lookup("Text[text='Update Stock of Medicine']");
        assertNotNull(sectionTitle);
    }

    @Test
    public void testDetailFields() {
        // Verify medicine detail fields
        assertNotNull("Name field missing", root.lookup("#StcokMeds_name"));
        assertNotNull("Description field missing", root.lookup("#StcokMeds_desciption"));
        assertNotNull("Price field missing", root.lookup("#StcokMeds_price"));
        assertNotNull("Current stock field missing", root.lookup("#StcokMeds_currentstock"));
    }

    @Test
    public void testButtonConfiguration() {
        Button addButton = (Button) root.lookup("#SearchMeds_Addbutton");
        Button backButton = (Button) root.lookup("#StockMeds_BackButton");
        
        assertEquals("ADD", addButton.getText());
        assertEquals("BACK", backButton.getText());
        assertTrue("Add button missing style class", 
                  addButton.getStyleClass().contains("create-btn"));
    }

    @Test
    public void testComboBoxProperties() {
        ComboBox<?> combo = (ComboBox<?>) root.lookup("#StcokMeds_Combobox");
        assertEquals("Search", combo.getPromptText());
        assertEquals(150, (int) combo.getPrefWidth());
    }

    @Test
    public void testInputFieldProperties() {
        TextField stockField = (TextField) root.lookup("#StcokMeds_addstock");
        assertEquals(184, (int) stockField.getPrefWidth());
        assertEquals(25, (int) stockField.getPrefHeight());
    }

    @Test
    public void testControllerAssociation() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.load(getClass().getResource("/ui/UpdateStock.fxml").openStream());
            assertNotNull("Controller not associated", loader.getController());
        } catch (Exception e) {
            fail("Controller test failed: " + e.getMessage());
        }
    }
}