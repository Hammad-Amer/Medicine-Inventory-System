package com.medstore.tests;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import Backend.Medicine;
import Backend.Supplier;
import Database.DBhandler;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import ui.Controller;

public class ControllerTest2 {
    private Controller controller;
    private Connection connection;

    @BeforeClass
    public static void initJFX() {
        new JFXPanel(); // Initialize JavaFX environment
    }

    @Before
    public void setUp() throws Exception {
        controller = new Controller();
        
        // Get DB connection from DBhandler
        DBhandler dbHandler = DBhandler.getInstance();
        Field connectionField = DBhandler.class.getDeclaredField("connection");
        connectionField.setAccessible(true);
        connection = (Connection) connectionField.get(dbHandler);
        connection.setAutoCommit(false);
        
        // Initialize required UI components
        initComponents();
    }

    private void initComponents() throws Exception {
        // Initialize FXML components using reflection
        setField("SearchMeds_Combobox", new ComboBox<>());
        setField("AddMeds_name", new TextField());
        setField("AddMeds_price", new TextField());
        setField("LowMeds_maintextarea", new TextArea());
        setField("DelSupp_Combobox", new ComboBox<>());
        
        // Trigger initialize method
        Platform.runLater(() -> controller.initialize());
    }

    @After
    public void tearDown() throws SQLException {
        connection.rollback();
        connection.setAutoCommit(true);
    }

    private void setField(String fieldName, Object value) throws Exception {
        Field field = Controller.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(controller, value);
    }

    @Test
    public void testHandleLoginValid() throws Exception {
        // Setup test user
        try (var stmt = connection.prepareStatement(
            "INSERT INTO User1 (username1, password1) VALUES (?, ?)")) {
            stmt.setString(1, "testUser");
            stmt.setString(2, "testPass");
            stmt.executeUpdate();
        }
        
        // Set login fields
        setField("login_username", new TextField("testUser"));
        setField("login_password", new TextField("testPass"));
        
        controller.handleLogin(new ActionEvent());
        
        assertEquals("testUser", Controller.getUser());
        assertTrue(getLatestLog().contains("Logged into the application"));
    }

    @Test
    public void testAddMedicine() throws Exception {
        // Set add medicine fields
        ((TextField) getField("AddMeds_name")).setText("TestMed");
        ((TextField) getField("AddMeds_price")).setText("100");
        // Set other required fields...
        
        controller.handleAddMedicine(new ActionEvent());
        
        Medicine med = DBhandler.getInstance().getMedicineDetails("TestMed");
        assertNotNull(med);
        assertEquals(100, med.getPrice());
        assertTrue(getLatestLog().contains("Added medicine"));
    }

    @Test
    public void testLowStockDisplay() throws Exception {
        // Add low stock medicine
        Medicine lowStockMed = new Medicine("LowMed", "Test", 10, 5, "2023-01-01", "2024-01-01");
        DBhandler.getInstance().addMedicine(lowStockMed);
        
        controller.fillLowMedsTextArea();
        
        String displayText = ((TextArea) getField("LowMeds_maintextarea")).getText();
        assertTrue(displayText.contains("LowMed (Stock: 5)"));
    }

    @Test
    public void testSupplierManagement() throws Exception {
        // Test supplier addition
        Supplier supplier = new Supplier("TestSupplier", "555-1234", "test@test.com", "Test Address", "LIC123");
        DBhandler.getInstance().addSupplier(supplier);
        
        // Test supplier display
        controller.initializeDeleteSupplierUI();
        ComboBox<String> combo = (ComboBox<String>) getField("DelSupp_Combobox");
        assertTrue(combo.getItems().contains("TestSupplier"));
        
        // Test supplier deletion
        combo.getSelectionModel().select("TestSupplier");
        controller.handleDeleteSupplier(new ActionEvent());
        assertFalse(DBhandler.getInstance().getAllSupplierNames().contains("TestSupplier"));
    }

    private String getLatestLog() throws SQLException {
        List<String> logs = DBhandler.getInstance().getLogsDescending();
        return logs.isEmpty() ? "" : logs.get(0);
    }

    private Object getField(String fieldName) throws Exception {
        Field field = Controller.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(controller);
    }
}