package Backend;

public class Sales {
    private int saleID;
    private int medicineID;
    private int quantityBought;

    public Sales(int saleID, int medicineID, int quantityBought) {
        this.saleID = saleID;
        this.medicineID = medicineID;
        this.quantityBought = quantityBought;
    }

    public int getSaleID() { return saleID; }
    public int getMedicineID() { return medicineID; }
    public int getQuantityBought() { return quantityBought; }
}
