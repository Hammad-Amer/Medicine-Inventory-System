package Backend;

public class StoreManager extends User {
    public StoreManager(int userID, String email, String password) {
        super(userID, email, password);
    }

    public void manageInventory() {
        System.out.println("Managing inventory...");
    }

    public void placeOrder() {
        System.out.println("Placing an order...");
    }
}
