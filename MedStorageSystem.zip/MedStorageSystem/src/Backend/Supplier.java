package Backend;

public class Supplier {
    private String supplierName;
    private String phone;
    private String email;
    private String address;
    private String licenseNumber;

    // Constructor
    public Supplier(String supplierName, String phone, String email, String address, String licenseNumber) {
        this.supplierName = supplierName;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.licenseNumber = licenseNumber;
    }

    // Getters
    public String getSupplierName() {
        return supplierName;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }
}
