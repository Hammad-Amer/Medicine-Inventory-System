module MedStorageSystem {
	requires javafx.controls;
	requires javafx.fxml;
	requires java.sql;
	requires javafx.graphics;
	requires junit;
	requires org.junit.jupiter.api;
	requires org.junit.platform.suite.api;
	requires javafx.swing;
	
	opens ui to javafx.fxml; 
	opens application to javafx.graphics, javafx.fxml;
	
	exports com.medstore.tests to junit;
}